﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RomaniaTuristica
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (User.Identity.IsAuthenticated)
            {
                this.lbUserId.Text = Membership.GetUser().ProviderUserKey.ToString();
            }
            else
            {
                this.lbUserId.Text = "No.";
            }
        }
    }
}