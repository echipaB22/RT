﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;

namespace RomaniaTuristica.App_Code
{
    public class ImageExtraction
    {
        public string currentPath = AppDomain.CurrentDomain.BaseDirectory + "bin";
        public string imagesPath = "http://romanian-explorer.com/Obiective%20judete/";
        public Utils ut = new Utils();

        public string getImageUrl(char[] img, string county)
        {
            string ret = "";

            for (int i = 1; i < img.Length - 2; i++)
            {
                ret = ret + img[i].ToString();
            }

            ret = imagesPath + county + "/" + ret;
            return ret;
        }

        public List<string> getNameList()
        {
            SqlDataReader reader = null;
            SqlConnection connection = new SqlConnection();
            List<string> nameList = new List<string>();
            SqlCommand command = new SqlCommand("SELECT * FROM CrawlerTable", connection);
            connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Database"].ConnectionString;

            try
            {
                connection.Open();
                reader = command.ExecuteReader();

                while (reader.Read())
                {
                    string name = (string)reader["Name"];
                    nameList.Add(name);
                }
            }
            finally
            {
                reader.Close();
                connection.Close();
            }
            return nameList;
        }

        public int getIdToAddTitleToDatabase(char[] title)
        {
            string ret = "";
            bool startAppending = false;
            bool isFirstSpace = true;

            for (int i = 1; i < title.Length; i++)
            {
                if (title[i] == '_' || title[i] == '-' || title[i] == ' ')
                {
                    if (isFirstSpace == false)
                    {
                        ret = ret + ' '.ToString();
                    }
                    else
                    {
                        startAppending = true;
                        isFirstSpace = false;
                    }
                }
                if ((title[i] >= 'a' && title[i] <= 'z') || (title[i] >= 'A' && title[i] <= 'Z'))
                {
                    if(startAppending == true)
                        ret = ret + title[i].ToString();
                }
                if (title[i] == '"')
                    break;
            }
            
            ////////////////////////////  database connection and retrival of information
            List<string> nameList = new List<string>();
            nameList = getNameList();

            int j;
            for (j = 0; j < nameList.Count; j++)
            {
                string aux = nameList[j].ToLower();
                if (aux.IndexOf(ret) != -1)
                    break;
            }

            if (j < nameList.Count)
                ret = nameList[j];
            else
                return -1;
            int id = 0;
            
            SqlDataReader reader = null;
            SqlConnection connection = new SqlConnection();
            SqlCommand command = new SqlCommand("SELECT Id FROM CrawlerTable WHERE Name = (@param1)", connection);
            connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Database"].ConnectionString;

            try
            {
                command.Parameters.AddWithValue("@param1", ret);
                connection.Open();
                reader = command.ExecuteReader();

                while (reader.Read())
                {
                    id = (int) reader["Id"];
                }
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }

                if (connection != null)
                {
                    connection.Close();
                }
            }
            return id;
        }

        public string getOnlyCharacters(string str)
        {
            char[] chrs = str.ToCharArray();
            string ret = "";

            for (int i = 0; i < chrs.Length; i++)
            {
                if ((chrs[i] >= 'a' && chrs[i] <= 'z') || (chrs[i] >= 'A' && chrs[i] <= 'Z'))
                    ret = ret + chrs[i].ToString();
            }

            return ret;
        }

        public string getCounty(string str)
        {
            string[] title = Regex.Split(str, "title>");
            string[] countyPart = Regex.Split(title[1], " ");

            return getOnlyCharacters(ut.transformToEnglish(countyPart[1]));
        }

        public void getImages(string line)
        {
            string[] lines = Regex.Split(line, "casuta-tabel-poze");
            string county = getCounty(lines[0]);
            string imagePart = lines[1];
            string titlePart = "";

            string[] allimages = Regex.Split(imagePart, "poza-2");

            for (int i = 1; i < allimages.Length; i++)
            {
                string[] everyImage = Regex.Split(allimages[i], "img src=");

                string[] titles = Regex.Split(everyImage[1], "alt=");
                imagePart = titles[0];
                titlePart = titles[1];


                char[] image = imagePart.ToCharArray();
                imagePart = getImageUrl(image, county);
                if (imagePart != null)
                {
                    char[] title = titlePart.ToCharArray();
                    int id = getIdToAddTitleToDatabase(title);

                    /////// database add image to the id of location

                    SqlConnection connection = new SqlConnection();
                    SqlCommand command = new SqlCommand("UPDATE CrawlerTable  SET Image = @param1 WHERE Id = @param2", connection);
                    connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Database"].ConnectionString;

                    command.Parameters.AddWithValue("@param1", imagePart);
                    command.Parameters.AddWithValue("@param2", id);

                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                    }
                    finally
                    {
                        if (connection != null)
                        {
                            connection.Close();
                        }
                    }
                }
            }
        }

        public void setImages(string str)
        {
            string line = System.IO.File.ReadAllText(@str);
            getImages(line);
        }
    }
}