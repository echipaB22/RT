﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;

namespace RomaniaTuristica.App_Code
{
    public class FileGeneration
    {
        public List<string> fileNameArray = new List<string>();
        public string currentPath = AppDomain.CurrentDomain.BaseDirectory + "bin";

        public string convertCharArrayToString(char[] ret)
        {
            string aux = "";

            for (int i = 0; i < ret.Length; i++)
            {
                if ((ret[i] >= 'a' && ret[i] <= 'z') || (ret[i] >= 'A' && ret[i] <= 'Z'))
                    aux = aux + ret[i].ToString();
            }
            return aux;
        }

        public string getCountyName(string url)
        {
            char[] str = url.ToCharArray();
            int count = 0;
            char[] ret = new char[20];
            int j = 0;

            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == '/')
                    count++;
                if (count == 4 && str[i] != '/')
                {
                    ret[j] = str[i];
                    j++;
                }
            }

            return convertCharArrayToString(ret);
        }

        public void savePageSourceCode(string url)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            WebClient client = new WebClient();


            StreamReader sr = new StreamReader(response.GetResponseStream());
            StringBuilder sb = new StringBuilder();
            sb.Append(sr.ReadToEnd());
            string fileName = "file_" + getCountyName(url) + ".txt";
            fileNameArray.Add(fileName);

            using (StreamWriter outfile = new StreamWriter(Path.GetFullPath(currentPath) + Path.DirectorySeparatorChar.ToString() + @fileName))
            {
                outfile.Write(sb.ToString());
            }
        }
    }
}
