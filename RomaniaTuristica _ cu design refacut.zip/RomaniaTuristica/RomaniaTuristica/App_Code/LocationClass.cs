﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomaniaTuristica.App_Code
{
    public class LocationClass
    {
        private string Name;
        private string County;
        private string Description;
        private string Image;
        private double Longitude;
        private double Latitude;

        public void setName(string str)
        {
            this.Name = str;
        }

        public void setCounty(string str)
        {
            this.County = str;
        }

        public void setDescription(string str)
        {
            this.Description = str;
        }

        public void setImage(string str)
        {
            this.Image = str;
        }

        public void setLongitude(double nr)
        {
            this.Longitude = nr;
        }

        public void setLatitude(double nr)
        {
            this.Latitude = nr;
        }

        public string getName()
        {
            return this.Name;
        }

        public string getCounty()
        {
            return this.County;
        }

        public string getDescription()
        {
            return this.Description;
        }

        public string getImage()
        {
            return this.Image;
        }

        public double getLatitude()
        {
            return this.Latitude;
        }

        public double getLongitude()
        {
            return this.Longitude;
        }
    }
}
