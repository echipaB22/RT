﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;

namespace RomaniaTuristica.App_Code
{
    public class ParseFile
    {
        public string county;
        public string currentPath = AppDomain.CurrentDomain.BaseDirectory + "bin";

        public string crawlForLink(string line)
        {
            string[] link = Regex.Split(line, "harta");
            string[] aux = Regex.Split(link[1], "width");
            string[] str = Regex.Split(aux[0], "src");

            char[] chrs = str[1].ToCharArray();
            string ret = "";
            for (int i = 2; i < chrs.Length - 2; i++)
            {
                ret = ret + chrs[i].ToString();
            }

            return ret;
        }

        public string getOnlyCharacters(char[] chrs)
        {
            string str = "";

            for (int a = 0; a < chrs.Length; a++)
            {
                if (chrs[a] >= '0' && chrs[a] <= '9')
                    break;
                if ((chrs[a] >= 'a' && chrs[a] <= 'z') || (chrs[a] >= 'A' && chrs[a] <= 'Z') || chrs[a] == 'ş' || chrs[a] == 'ţ' || chrs[a] == 'ă' || chrs[a] == 'î' || chrs[a] == 'â' || chrs[a] == ' ')
                {
                    str = str + chrs[a].ToString();
                }
                    
            }
            return str;
        }

        public void addToDatabase(LocationClass lc)
        {
            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Database"].ConnectionString;

            using (SqlCommand command = connection.CreateCommand())
            {
                command.CommandText = "INSERT INTO CrawlerTable (Name, Longitude, Latitude, County) VALUES (@param1, @param2, @param3, @param4)";

                command.Parameters.AddWithValue("@param1", lc.getName());
                command.Parameters.AddWithValue("@param2", lc.getLongitude());
                command.Parameters.AddWithValue("@param3", lc.getLatitude());
                command.Parameters.AddWithValue("@param4", lc.getCounty());

                connection.Open();
                command.ExecuteNonQuery();
            }
            connection.Close();
        }

        public string transformToEnglish(string str)
        {
            char[] chrs = str.ToArray();
            string ret = "";

            for (int i = 0; i < chrs.Length; i++)
            {
                if (chrs[i] == 'ş')
                    chrs[i] = 's';
                if (chrs[i] == 'ţ')
                    chrs[i] = 't';
                if (chrs[i] == 'ă' || chrs[i] == 'î' || chrs[i] == 'â')
                    chrs[i] = 'a';
                ret = ret + chrs[i].ToString();
            }

            return ret;
        }

        public bool isAlreadyInDatabase(string str)
        {
            SqlDataReader reader = null;
            SqlConnection connection = new SqlConnection();
            List<string> nameList = new List<string>();
            SqlCommand command = new SqlCommand("SELECT * FROM CrawlerTable", connection);
            connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Database"].ConnectionString;

            try 
            {
                connection.Open();
                reader = command.ExecuteReader();

                while (reader.Read())
                {
	                string name = (string) reader ["Name"];
                    nameList.Add(name);
                }
            }
            finally
			{
				reader.Close();
				connection.Close();
			}	

            for (int i = 0; i < nameList.Count; i++)
            {
                if (nameList[i].Equals(transformToEnglish(str)))
                    return true;
            }

            return false;
        }

        public void deleteAllFromDatabase()
        {
            SqlConnection connection = new SqlConnection();
            SqlCommand command = new SqlCommand("DELETE FROM CrawlerTable", connection);
            connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Database"].ConnectionString;

            try
            {
                connection.Open();
                command.ExecuteNonQuery();
            }
            finally
            {
                connection.Close();
            }	
        }

        public void getNameAndGeometryOfLocation(string str)
        {
            string[] res = Regex.Split(str, "name");

            for (int i = 1; i < res.Length - 1; i++)
            {
                string[] aux = Regex.Split(res[i], "gme_geometry_");
                string namePart = aux[0];
                string geometryPart = aux[1];

                char[] nameChars = namePart.ToCharArray(8, 100);
                char[] geomChars = geometryPart.ToCharArray(11, 50);

                namePart = "";
                geometryPart = "";

                for (int b = 0; b < nameChars.Length; b++)
                {
                    namePart = namePart + nameChars[b].ToString();
                }

                for (int b = 0; b < geomChars.Length; b++)
                {
                    geometryPart = geometryPart + geomChars[b].ToString();
                }

                string[] retaux = Regex.Split(namePart, ",");
                string[] ret = Regex.Split(geometryPart, ",");

                namePart = "";
                nameChars = new char[retaux.Length];
                nameChars = retaux[0].ToCharArray();
                namePart = getOnlyCharacters(nameChars);

                LocationClass lc = new LocationClass();
                lc.setName(namePart);
                lc.setCounty(county);
                lc.setLongitude(Convert.ToDouble(ret[1]));
                lc.setLatitude(Convert.ToDouble(ret[0]));

                if (isAlreadyInDatabase(lc.getName()) == false)
                    addToDatabase(lc);
            }
        }

        public void getInformationFromFile(string str)
        {
            char[] chrs = new char[20];
            string[] lines = Regex.Split(str, "Judeţul");    //in lines[1] este ceea ce ne trebuie
            string lastPartOfLine = lines[1];
            chrs = lines[1].ToCharArray(1, 20);
            string ret = "";

            for (int i = 0; i < chrs.Length; i++)
            {
                ret = ret + chrs[i].ToString();
            }

            string[] aux = Regex.Split(ret, ",");
            char[] auxch = aux[0].ToCharArray();
            ret = "";

            for (int i = 0; i < auxch.Length; i++)
            {
                if ((auxch[i] >= 'a' && auxch[i] <= 'z') || (auxch[i] >= 'A' && auxch[i] <= 'Z') || auxch[i] == 'ă' || auxch[i] == 'î' || auxch[i] == 'â' || auxch[i] == 'ş' || auxch[i] == 'ţ')
                {
                    ret = ret + auxch[i].ToString();
                }
            }
            county = ret;

            getNameAndGeometryOfLocation(lastPartOfLine);
        }

        public void getDetailsOfLocations(string link)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(link);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            WebClient client = new WebClient();


            StreamReader sr = new StreamReader(response.GetResponseStream());
            StringBuilder sb = new StringBuilder();
            sb.Append(sr.ReadToEnd());

            getInformationFromFile(sb.ToString());
        }

        public void parseFilePath(string str)
        {
            string line = System.IO.File.ReadAllText(@str);
            string link = crawlForLink(line);

            getDetailsOfLocations(link);
        }

    }
}
