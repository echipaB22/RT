﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RomaniaTuristica.App_Code
{
    public class Utils
    {
        public string getOnlyCharacters(char[] chrs)
        {
            string str = "";

            for (int a = 0; a < chrs.Length; a++)
            {
                if ((chrs[a] >= 'a' && chrs[a] <= 'z') || (chrs[a] >= 'A' && chrs[a] <= 'Z') || chrs[a] == 'ş' || chrs[a] == 'ţ' || chrs[a] == 'ă' || chrs[a] == 'î' || chrs[a] == 'â' || chrs[a] == ' ' || chrs[a] == 'Î')
                {
                    str = str + chrs[a].ToString();
                }

            }
            return str;
        }

        public string getOnlyCharactersAndNumbers(char[] chrs)
        {
            string str = "";

            for (int a = 0; a < chrs.Length; a++)
            {
                if ((chrs[a] >= 'a' && chrs[a] <= 'z') || (chrs[a] >= 'A' && chrs[a] <= 'Z') || chrs[a] == 'ş' || chrs[a] == 'ţ' || chrs[a] == 'ă' || chrs[a] == 'î' || chrs[a] == 'â' || chrs[a] == ' ' || (chrs[a] >= '0' && chrs[a] <= '9'))
                {
                    str = str + chrs[a].ToString();
                }

            }
            return str;
        }

        public string transformToEnglish(string str)
        {
            char[] chrs = str.ToArray();
            string ret = "";

            for (int i = 0; i < chrs.Length; i++)
            {
                if (chrs[i] == 'ş')
                    chrs[i] = 's';
                if (chrs[i] == 'ţ')
                    chrs[i] = 't';
                if (chrs[i] == 'ă' || chrs[i] == 'î' || chrs[i] == 'â')
                    chrs[i] = 'a';
                ret = ret + chrs[i].ToString();
            }

            return ret;
        }
    }
}