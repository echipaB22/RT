﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;

namespace RomaniaTuristica.App_Code
{
    public class DescriptionExtraction
    {
        public string currentPath = AppDomain.CurrentDomain.BaseDirectory + "bin";
        public Utils ut = new Utils();

        public int getIdFromDatabaseWithTheName(string name)
        {
            int id = -1;
            SqlDataReader reader = null;
            SqlConnection connection = new SqlConnection();
            SqlCommand command = new SqlCommand("SELECT Id FROM CrawlerTable WHERE Name = (@param1)", connection);
            connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Database"].ConnectionString;

            try
            {
                command.Parameters.AddWithValue("@param1", name);
                connection.Open();
                reader = command.ExecuteReader();

                while (reader.Read())
                {
                    id = (int)reader["Id"];
                }
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }

                if (connection != null)
                {
                    connection.Close();
                }
            }
            return id;
        }

        public void insertIntoDatabaseDescriptionAtId(int id, string desc)
        {
            SqlConnection connection = new SqlConnection();
            SqlCommand command = new SqlCommand("UPDATE CrawlerTable  SET Description = @param1 WHERE Id = @param2", connection);
            connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Database"].ConnectionString;

            command.Parameters.AddWithValue("@param1", desc);
            command.Parameters.AddWithValue("@param2", id);

            try
            {
                connection.Open();
                command.ExecuteNonQuery();
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                }
            }
        }

        public void addDescriptionToDatabase(string title, string content)
        {

            ///get the list of names in the database
            ///
            SqlDataReader reader = null;
            SqlConnection connection = new SqlConnection();
            List<string> nameList = new List<string>();
            SqlCommand command = new SqlCommand("SELECT * FROM CrawlerTable", connection);
            connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["Database"].ConnectionString;

            try
            {
                connection.Open();
                reader = command.ExecuteReader();

                while (reader.Read())
                {
                    string name = (string)reader["Name"];
                    nameList.Add(name);
                }
            }
            finally
            {
                reader.Close();
                connection.Close();
            }

            /////find the name that fits the title
            int i;
            for (i = 0; i < nameList.Count; i++)
            {
                if (nameList[i].IndexOf(title) != -1)
                    break;
            }

            if(i < nameList.Count) {
                int id = getIdFromDatabaseWithTheName(nameList[i]);
                if (id != -1)
                {
                    insertIntoDatabaseDescriptionAtId(id, content);
                }
            }
        }

        public void parseDescription(string str)
        {
            string[] lines = Regex.Split(str, "titlucoment");
            string[] restLines = Regex.Split(lines[1], "continutcoment");

            string title = lines[1];
            string content = restLines[1];

            string[] titles = Regex.Split(title, "</div");
            string[] contents = Regex.Split(content, "</div");

            title = titles[0];
            content = contents[0];

            char[] titleChrs = title.ToCharArray();
            char[] contentChars = content.ToCharArray();

            title = ut.transformToEnglish(ut.getOnlyCharacters(titleChrs));
            content = ut.getOnlyCharactersAndNumbers(contentChars);

            addDescriptionToDatabase(title, content);
        }

        public void getDescription(string str)
        {
            string line = System.IO.File.ReadAllText(@str);
            parseDescription(line);
        }
    }
}