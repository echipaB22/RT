﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DefaultTopic : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnAdauga_Click(object sender, EventArgs e)
    {
          if (FileUpload1.HasFile )
        {
            try
            {
               /* string imgPath;
                FileUpload1.SaveAs("C:\\Users\\lilia\\Desktop\\imagini\\" + FileUpload1.FileName);
                imgPath = "C:\\Users\\lilia\\Desktop\\imagini\\" + FileUpload1.FileName; */
               // if (File.Exists(imgPath))
                 if (FileUpload1.PostedFile != null)
    
                {
                    string FileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
                    FileUpload1.SaveAs(Server.MapPath("images/" + FileName));
                    int length = FileUpload1.PostedFile.ContentLength;
                    byte[] imgbyte = new byte[length];
                    HttpPostedFile img = FileUpload1.PostedFile;
                    img.InputStream.Read(imgbyte, 0, length);
                    string comentariu = tbComentariu.Text;
                    var UserFromDb = System.Web.Security.Membership.GetUser();
                    var UserId = UserFromDb.ProviderUserKey;
                     var nume = User.Identity.Name;
                     var IdTopic= HttpContext.Current.Request["p"];
                     
           
                   
                    string connectionString = ConfigurationManager.ConnectionStrings["Database"].ConnectionString;
                    SqlConnection con = new SqlConnection(connectionString);
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Insert into Comentarii(UserId,TopicId,Comentariu,Imagine,UserName) values (@UserId,@IdTopic,@comentariu,@FilePath,@nume)", con);

                    cmd.Parameters.AddWithValue("@comentariu", comentariu);
                    cmd.Parameters.AddWithValue("@UserId",UserId);
                    cmd.Parameters.AddWithValue("@nume",nume);
                    cmd.Parameters.AddWithValue("@FilePath", "images/" +FileName);
                    cmd.Parameters.AddWithValue("@IdTopic", IdTopic);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    lblMessage.Text = "Insert Success";

                    tbComentariu.Text = string.Empty;
                      }
                else
                {
                    lblMessage.Text =  " not found ";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "File Upload Failed!!!" + ex.Message.ToString();
            }
        }
        else
        {
            lblMessage.Text = "Please select a file ";
        }
    }
   
    
 private byte[] imgStream(string fileName)
	{
		MemoryStream stream = new MemoryStream();
	tryagain:
		try
		{
			Bitmap bmp = new Bitmap(fileName);
			bmp.Save(stream, System.Drawing.Imaging.ImageFormat.Jpeg);
		}
		catch (Exception ex)
		{
			goto tryagain;
		}

		return stream.ToArray();
	}
   
}
