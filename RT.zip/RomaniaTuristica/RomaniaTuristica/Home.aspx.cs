﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HtmlAgilityPack;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
using RomaniaTuristica.App_Code;


public partial class Home : System.Web.UI.Page
{
    public string currentPath = AppDomain.CurrentDomain.BaseDirectory + "/bin";

    public void Page_Load(object sender, EventArgs e)
    {
        FileGeneration fg = new FileGeneration();
        ParseFile pf = new ParseFile();
        ImageExtraction ie = new ImageExtraction();
        DescriptionExtraction de = new DescriptionExtraction();

        string fileName = Path.GetFullPath(currentPath);
        fileName = fileName + Path.DirectorySeparatorChar.ToString() + "linksFile.txt";
        string[] lines = System.IO.File.ReadAllLines(@fileName);
        string mydocpath = Path.GetFullPath(currentPath);

        for (int i = 0; i < lines.Length; i++)
        {
            fg.savePageSourceCode(lines[i]);
        }

        //pf.deleteAllFromDatabase(); //in case database gets corrupted and you want to reintroduce everything (it takes some time)

        for (int i = 0; i < fg.fileNameArray.Count; i++)
        {
            string file = mydocpath + Path.DirectorySeparatorChar.ToString() + fg.fileNameArray[i];
            pf.parseFilePath(file);
            ie.setImages(file);
            de.getDescription(file);
        }
    }
}