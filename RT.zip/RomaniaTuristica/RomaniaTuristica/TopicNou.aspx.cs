﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TopicNou : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
              String nume = TbTopic.Text;
            String descriere = Tbdescriere.Text;
            string autor= string.Empty  ;
            if (User.Identity.IsAuthenticated)
            {
                autor = Membership.GetUser().ProviderUserKey.ToString();
            }
        else
            {
           Response.Redirect("Default.aspx");
             }
               
            string connectionString = ConfigurationManager.ConnectionStrings["Database"].ConnectionString;
          /*  SqlConnection connex = new SqlConnection(connectionString);      
        connex.Open();
       
        SqlCommand coma=new SqlCommand( "Select count(Titlu) from Topic where Titlu  like '@nume'",connex);
        coma.ExecuteNonQuery();
      object   total_number  = coma.ExecuteNonQuery();

      if (total_number.Equals(System.DBNull.Value))
      {*/
          SqlConnection con = new SqlConnection(connectionString);
          con.Open();
          SqlCommand cmd = new SqlCommand("Insert into Topic(Titlu, UserId,Descriere) values (@nume,@autor,@descriere)", con);
          cmd.Parameters.AddWithValue("@nume", nume);
          cmd.Parameters.AddWithValue("@autor", Guid.Parse(autor.ToString()));
          cmd.Parameters.AddWithValue("@descriere", descriere);
          cmd.ExecuteNonQuery();


          SqlConnection conn = new SqlConnection(connectionString);
          conn.Open();
          string qry = null;
         
          int I = 0;
          for (I = 0; I < chk.Items.Count; I++)
          {
              if (chk.Items[I].Selected == true)
              {
                  Guid inputvalue = Guid.Parse(chk.Items[I].Value);
                  qry = "INSERT INTO Utiliz_Topic (UserId,Accept,Titlu) VALUES (@inputvalue,'Nu',@nume)";
                  SqlCommand comand = new SqlCommand(qry, conn);
                  comand.Parameters.AddWithValue("@inputvalue", inputvalue);
                  comand.Parameters.AddWithValue("@nume", nume);

                  comand.ExecuteNonQuery();

              }
          }
          conn.Close();
          con.Close();
         


          /* string connectionString1 = ConfigurationManager.ConnectionStrings["Database"].ConnectionString;
           SqlConnection con1 = new SqlConnection(connectionString);
           con1.Open();
           //String idT = "Select Id from Topic where Titlu = '@nume' ";
           //SqlCommand comm = new SqlCommand(idT, con1);
           SqlCommand cmd1 = new SqlCommand("Insert into Comentarii(UserId, TopicId, Comentariu, Imagine) values ('522a1203-6de8-450a-aa7a-70de86fd64da', 'Select Id from Topic where Titlu = '@nume'', @post1, @FilePath)", con1);
           cmd1.Parameters.AddWithValue("@nume", nume);
         //  cmd1.Parameters.AddWithValue("@autor", autor);
           //cmd1.Parameters.AddWithValue("@idT", idT);
           cmd1.Parameters.AddWithValue("@post1", post1);
           cmd1.Parameters.AddWithValue("@FilePath", "images/" + FileName);
           cmd1.ExecuteNonQuery();
           con1.Close();
          */

          lblMessage.Text = "Succes";
          Tbdescriere.Text = string.Empty;
          TbTopic.Text = string.Empty;
          chk.SelectedIndex = -1;
      
     /* else
      {
          lblMessage.Text = "Nu puteti avea un topic cu asa titlu";
      }
               
    */

            //                  TbTopic.Text = string.Empty; 
            /*     }
          else 
                 { 
                 lblMessage.Text = " not found "; 
                 } 
                    
 } 
              
catch (Exception ex) { 
     lblMessage.Text = "File Upload Failed!!!" + ex.Message.ToString(); 
 } 
//else { lblMessage.Text = "Please select a file "; } 
} 
private byte[] imgStream(string fileName) {
MemoryStream stream = new MemoryStream(); tryagain: 
 try { 
     Bitmap bmp = new Bitmap(fileName); 
     bmp.Save(stream, System.Drawing.Imaging.ImageFormat.Jpeg); 
 } catch (Exception ex) { goto tryagain; }
*/
            //return stream.ToArray(); 
        } 
    }
